""" This file was generated when pyedbglib was built """
VERSION = '2.15.2.58'
COMMIT_ID = '2ee2a8126114d22f31cd8e38c7cf5ae54b09acab'
BUILD_DATE = '2020-10-07 14:42:00 +0000'
