# Here live the bootloader hex files

## .lst and .elf files

Additionally, there is a tar'ed BZip'ed copy of all the assembly listings and elf files produced compiling all of these bootloaders, these are in listings.tar.bz2 and elves.tar.bz2.

## Build logs

Build logs are now included of both normal output and error output.
