# Step-by-step guide to turn a uno/nano/pro mini OR a serial adapter into a UPDI programmer

Moved - there were multiple versions of this in multiple repos - now all copies have moved here:

[https://github.com/SpenceKonde/AVR-Guidance/blob/master/UPDI/jtag2updi.md](https://github.com/SpenceKonde/AVR-Guidance/blob/master/UPDI/jtag2updi.md)

Do note also that there is now the option to program with just a serial adapter and resistor, 'pyupdi'-style.
